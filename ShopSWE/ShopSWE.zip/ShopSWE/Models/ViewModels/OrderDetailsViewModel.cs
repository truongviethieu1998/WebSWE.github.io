﻿using ShopSWE.Models.Enity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopSWE.Models.ViewModels
{
    public class OrderDetailsViewModel
    {
        public List<OrderDetail> orderDetails { get; set; }      
    }
}